#ifndef __RTC_H__
#define __RTC_H__

void RTC_Init(void);
void RTCSetTime(u32,u32,u32);

#endif
